/*    */ package BOOT-INF.classes.io.tricking.challenge;
/*    */ 
/*    */ import org.springframework.boot.SpringApplication;
/*    */ import org.springframework.boot.autoconfigure.SpringBootApplication;
/*    */ 
/*    */ @SpringBootApplication
/*    */ public class ChallengeApplication
/*    */ {
/*    */   public static void main(String[] args) {
/* 10 */     SpringApplication.run(io.tricking.challenge.ChallengeApplication.class, args);
/*    */   }
/*    */ }


/* Location:              C:\Users\zhr_0\Desktop\challenge-0.0.1-SNAPSHOT.jar!\BOOT-INF\classes\io\tricking\challenge\ChallengeApplication.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */