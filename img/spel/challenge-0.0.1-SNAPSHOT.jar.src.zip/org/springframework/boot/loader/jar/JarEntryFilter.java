package org.springframework.boot.loader.jar;

interface JarEntryFilter {
  AsciiBytes apply(AsciiBytes paramAsciiBytes);
}


/* Location:              C:\Users\zhr_0\Desktop\challenge-0.0.1-SNAPSHOT.jar!\org\springframework\boot\loader\jar\JarEntryFilter.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */